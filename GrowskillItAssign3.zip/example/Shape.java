package org.example;

// Program to calculate area of Square, Rectangle and Circle using a single class

class Shape {
    double length; // instance variable

    // Method to find area of square
    void square(double side) {
        double area = side * side;
        System.out.println("Area of Square: " + area);
    }

    // Method to find area of rectangle
    void rectangle(double length, double breadth) {
        double area = length * breadth;
        System.out.println("Area of Rectangle: " + area);
    }

    // Method to find area of circle
    void circle(double radius) {
        double area = Math.PI * radius * radius;
        System.out.println("Area of Circle: " + area);
    }

    public static void main(String[] args) {
        Shape shape = new Shape(); // object creation

        // calling different methods
        shape.square(5);
        shape.rectangle(4, 6);
        shape.circle(3);
    }
}

