package org.example;

// Program to demonstrate School class with constructor and method

class School {
    String name;  // instance variable

    // Default constructor
    School() {
        name = "ABC Public School";   // assigning default value
        System.out.println("School Name: " + name);
    }

    // Method to display message
    void displayLocation() {
        System.out.println("This School is based out of Kolkata");
    }

    // main method
    public static void main(String[] args) {
        School school = new School();   // calling default constructor
        school.displayLocation();       // calling method
    }
}
