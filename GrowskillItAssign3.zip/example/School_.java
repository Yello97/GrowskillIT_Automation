package org.example;

public class School_ {
    String name;
    String address;
    int strength;

    // Constructor with 2 parameters
    School_(String name, String address) {
        this.name = name;
        this.address = address;
    }

    // Constructor with 3 parameters
    School_(String name, String address, int strength) {
        this.name = name;
        this.address = address;
        this.strength = strength;
    }

    // Method to display details
    void displayDetails() {
        System.out.println("School Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Strength: " + strength);
        System.out.println("--------------------------------");
    }

    // main method
    public static void main(String[] args) {
        // Object using constructor with 2 parameters
        School_ school1 = new School_("ABC Public School", "Kolkata");
        school1.displayDetails();

        // Object using constructor with 3 parameters
        School_ school2 = new School_("XYZ International School", "Delhi", 1200);
        school2.displayDetails();
    }
}

