package org.example;

// Car class
class Car {
    private String brand;

    // Constructor that initializes brand to "Ford"
    Car() {
        brand = "Ford";
    }

    // Getter method to return brand
    public String getBrand() {
        return brand;
    }
}

// Sample class with main method
class Sample {
    public static void main(String[] args) {
        Car myCar = new Car();              // calling constructor
        String carBrand = myCar.getBrand(); // storing brand value
        System.out.println("Car Brand: " + carBrand);
    }
}
